package variables;

public class Intro {
    public static void main(String[] args) {
        // System.out.println("Let me introduce myself");
        introduce();
        System.out.println("Juliko Bandito"); // first person
        // System.out.println("Let me introduce myself");
        introduce();
        System.out.println("De La Vorre Gangsterito"); //second
        // System.out.println("Let me introduce myself");
        introduce();
        System.out.println("Hulio Iglesias");// third

// don't repeat yourself

    }
    public static void introduce(){
        System.out.println("Let me introduce myself");
    }
}
