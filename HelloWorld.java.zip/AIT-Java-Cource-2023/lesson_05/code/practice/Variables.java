package practice;

public class Variables {
    public static void main(String[] args) {

        int a, b, res;
        a = 50; // наруральные целые положительные
        b = 50; //
        res = 0;

        if (a == b) {
            res = (a+b)*5;

        }
        if (a != b){
            res = (a - b)* 5;

        }

        System.out.println(res);

    }
}
