package practice;

public class Sadbox {
    public static void main(String[] args) {

    }
}
