package practice;

public class Rocket {
    public static void main(String[] args) {

        int countDown = 10;

        while (countDown >= 0){
            System.out.println(countDown);
            countDown --; // измение параметра цикла


        }
        System.out.println("Поехали!");
    }
}
