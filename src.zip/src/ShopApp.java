/**
 * @author Andrej Reutow
 * created on 16.10.2023
 */
public class ShopApp {

    public static void main(String[] args) {
        Product[] products = {
                new Laptop(1, "HP", 2500),
                new Laptop(2, "Lenovo", 2489),
                new Display(3, "Dell", 899.99),
                new Display(4, "Samsung", 299.99),
        };

        for (int i = 0; i < products.length; i++) {
            System.out.println("#".repeat(60));
            Product currentProduct = products[i];
            currentProduct.getPoductInfo();
            currentProduct.buyOnline();
            currentProduct.buyOffline();
        }
    }
}
